def main():
    print("Hello from super-todo!")


if __name__ == "__main__":
    main()
